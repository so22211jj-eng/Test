-- Snayder initial schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (char_length(username) between 2 and 24),
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.servers (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 80),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.server_members (
  server_id uuid not null references public.servers(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','admin','moderator','member')),
  joined_at timestamptz not null default now(),
  primary key(server_id,user_id)
);

create table if not exists public.channels (
  id uuid primary key default gen_random_uuid(),
  server_id uuid not null references public.servers(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 80),
  type text not null default 'text' check (type in ('text','voice')),
  created_at timestamptz not null default now(),
  unique(server_id,name)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  channel_id uuid not null references public.channels(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 4000),
  created_at timestamptz not null default now()
);
create index if not exists messages_channel_created_idx on public.messages(channel_id,created_at);

create table if not exists public.invites (
  code text primary key default encode(gen_random_bytes(8),'hex'),
  server_id uuid not null references public.servers(id) on delete cascade,
  created_by uuid not null references public.profiles(id) on delete cascade,
  uses integer not null default 0 check (uses >= 0),
  max_uses integer,
  expires_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  receiver_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','declined','blocked')),
  created_at timestamptz not null default now(),
  unique(sender_id,receiver_id),
  check(sender_id <> receiver_id)
);

create or replace function public.is_server_member(sid uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.server_members sm where sm.server_id=sid and sm.user_id=auth.uid()) $$;

create or replace function public.is_channel_member(cid uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.channels c join public.server_members sm on sm.server_id=c.server_id where c.id=cid and sm.user_id=auth.uid()) $$;

create or replace function public.is_server_admin(sid uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.server_members sm where sm.server_id=sid and sm.user_id=auth.uid() and sm.role in ('owner','admin')) $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
declare base_name text;
begin
  base_name := coalesce(nullif(new.raw_user_meta_data->>'username',''), split_part(new.email,'@',1), 'usuario');
  base_name := left(regexp_replace(base_name, '[^a-zA-Z0-9_.-]', '', 'g'), 24);
  if char_length(base_name) < 2 then base_name := 'usuario' || substr(new.id::text,1,6); end if;
  insert into public.profiles(id,username) values(new.id,base_name)
  on conflict(id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.servers enable row level security;
alter table public.server_members enable row level security;
alter table public.channels enable row level security;
alter table public.messages enable row level security;
alter table public.invites enable row level security;
alter table public.friend_requests enable row level security;

create policy "Profiles visible to signed in users" on public.profiles for select to authenticated using (true);
create policy "Users update own profile" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());

create policy "Members can see servers" on public.servers for select to authenticated using (public.is_server_member(id));
create policy "Signed-in users create servers as owner" on public.servers for insert to authenticated with check (owner_id=auth.uid());
create policy "Admins update server" on public.servers for update to authenticated using (public.is_server_admin(id)) with check (public.is_server_admin(id));
create policy "Owner deletes server" on public.servers for delete to authenticated using (owner_id=auth.uid());

create policy "Members list server members" on public.server_members for select to authenticated using (public.is_server_member(server_id));
create policy "Users join themselves" on public.server_members for insert to authenticated with check (user_id=auth.uid());
create policy "Admins remove members" on public.server_members for delete to authenticated using (public.is_server_admin(server_id) or user_id=auth.uid());
create policy "Admins update member roles" on public.server_members for update to authenticated using (public.is_server_admin(server_id)) with check (public.is_server_admin(server_id));

create policy "Members read channels" on public.channels for select to authenticated using (public.is_server_member(server_id));
create policy "Members create channels" on public.channels for insert to authenticated with check (public.is_server_member(server_id) and public.is_server_admin(server_id));
create policy "Admins update channels" on public.channels for update to authenticated using (public.is_server_admin(server_id)) with check (public.is_server_admin(server_id));
create policy "Admins delete channels" on public.channels for delete to authenticated using (public.is_server_admin(server_id));

create policy "Members read channel messages" on public.messages for select to authenticated using (public.is_channel_member(channel_id));
create policy "Members send messages as themselves" on public.messages for insert to authenticated with check (user_id=auth.uid() and public.is_channel_member(channel_id));
create policy "Authors edit their messages" on public.messages for update to authenticated using (user_id=auth.uid() and public.is_channel_member(channel_id)) with check (user_id=auth.uid() and public.is_channel_member(channel_id));
create policy "Authors or admins delete messages" on public.messages for delete to authenticated using (user_id=auth.uid() or exists(select 1 from public.channels c where c.id=channel_id and public.is_server_admin(c.server_id)));

create policy "Members can read server invites" on public.invites for select to authenticated using (public.is_server_member(server_id));
create policy "Members can create invites" on public.invites for insert to authenticated with check (created_by=auth.uid() and public.is_server_member(server_id));
create policy "Invite creator or admin updates invites" on public.invites for update to authenticated using (created_by=auth.uid() or public.is_server_admin(server_id)) with check (created_by=auth.uid() or public.is_server_admin(server_id));
create policy "Creator or admin deletes invites" on public.invites for delete to authenticated using (created_by=auth.uid() or public.is_server_admin(server_id));

create policy "Users see own friend requests" on public.friend_requests for select to authenticated using (sender_id=auth.uid() or receiver_id=auth.uid());
create policy "Users send friend requests" on public.friend_requests for insert to authenticated with check (sender_id=auth.uid());
create policy "Receiver updates requests" on public.friend_requests for update to authenticated using (receiver_id=auth.uid()) with check (receiver_id=auth.uid());
create policy "Participants delete requests" on public.friend_requests for delete to authenticated using (sender_id=auth.uid() or receiver_id=auth.uid());

-- Enable realtime for persistent message inserts.
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null;
when undefined_object then null;
end $$;

grant usage on schema public to authenticated;
grant select, insert, update, delete on public.profiles, public.servers, public.server_members, public.channels, public.messages, public.invites, public.friend_requests to authenticated;
