import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Snayder — comunidades y chat",
  description: "Conecta con tus comunidades en Snayder."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="es"><body>{children}</body></html>;
}
