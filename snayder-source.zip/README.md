# Snayder

Snayder is a real Next.js + Supabase community chat application starter. It is not a hosted service yet: each deployment must be connected to its own Supabase project.

## Included in this build

- Email/password sign-up and login
- User profiles created by a database trigger
- Create and switch between servers
- Create text channels and voice-channel placeholders
- Persistent channel messages with Supabase Realtime updates
- Invitation-code creation and joining
- Search within the currently loaded channel
- Responsive dark interface
- Row Level Security policies for core tables

## Requirements

- Node.js 20+
- A Supabase project
- A deployment host such as Vercel for public access

## 1. Configure Supabase

1. Create a project at https://supabase.com/
2. Open **SQL Editor** and run `supabase/migrations/001_initial_schema.sql`.
3. Open Project Settings → API and copy the Project URL and anon/public key.
4. Copy `.env.example` to `.env.local` and fill in the values:

```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

The anon key is intended for browser use when RLS is correctly configured. **Never put a Supabase service-role key in frontend code.**

## 2. Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## 3. Publish online

1. Push this project to a private or public GitHub repository.
2. Import the repository in Vercel.
3. Add both `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` to the Vercel project's environment variables.
4. Deploy.
5. In Supabase Auth settings, configure the site URL and allowed redirect URLs for your deployed domain.

## Current scope and production checklist

This code is a functional foundation, not feature parity with Discord. Voice/video calls need a dedicated WebRTC service (for example LiveKit), and direct messages/friend discovery, file uploads, reactions, moderation UI, rate limits, abuse reporting, and full invite acceptance UX still need implementation before calling it a full Discord replacement. Before public launch, review and test all RLS policies and invitation workflows, add abuse prevention and rate limits, and configure email verification and account recovery.

## Security note

Never expose service-role secrets. Review and test database policies in a separate test account before opening a public community.
