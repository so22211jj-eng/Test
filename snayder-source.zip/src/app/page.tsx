import Snayder from "@/components/Snayder";

export default function Home() {
  return <Snayder />;
}
