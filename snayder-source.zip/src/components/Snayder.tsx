 "use client";

import { useEffect, useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import {
  Hash, Headphones, Mic, Settings, Plus, Search, Users, Compass,
  MessageCircle, Send, LogOut, ChevronDown, Bell, Smile, Menu, X,
  ShieldCheck, Radio, UserPlus
} from "lucide-react";

type Server = { id: string; name: string; owner_id: string };
type Channel = { id: string; server_id: string; name: string; type: "text" | "voice" };
type ChatMessage = { id: string; channel_id: string; user_id: string; content: string; created_at: string; profiles?: { username: string; avatar_url: string | null } | null };

const colors = ["#8b5cf6", "#0891b2", "#d97706", "#db2777", "#16a34a"];

export default function Snayder() {
  const [supabase] = useState(() => createClient());
  const [session, setSession] = useState<any>(null);
  const [profileName, setProfileName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [authMode, setAuthMode] = useState<"login" | "signup">("login");
  const [authBusy, setAuthBusy] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [servers, setServers] = useState<Server[]>([]);
  const [activeServer, setActiveServer] = useState("");
  const [channels, setChannels] = useState<Channel[]>([]);
  const [activeChannel, setActiveChannel] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(true);
  const [showMembers, setShowMembers] = useState(false);
  const [mobileSidebar, setMobileSidebar] = useState(false);
  const [view, setView] = useState<"chat" | "friends">("chat");
  const [modal, setModal] = useState<"server" | "channel" | "invite" | "dm" | null>(null);
  const [modalName, setModalName] = useState("");
  const [search, setSearch] = useState("");
  const [sending, setSending] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setLoading(false); });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setLoading(false);
    });
    return () => listener.subscription.unsubscribe();
  }, [supabase]);

  useEffect(() => {
    if (!session) { setServers([]); setChannels([]); setMessages([]); return; }
    let cancelled = false;
    (async () => {
      const { data: profile } = await supabase.from("profiles").select("username").eq("id", session.user.id).maybeSingle();
      if (profile?.username) setProfileName(profile.username);
      const { data, error } = await supabase.from("server_members").select("server:servers(id,name,owner_id)").order("joined_at", { ascending: true });
      if (cancelled) return;
      if (error) { setError(error.message); return; }
      const rows = (data || []).map((r: any) => r.server).filter(Boolean) as Server[];
      setServers(rows);
      if (rows.length && !activeServer) setActiveServer(rows[0].id);
      if (!rows.length) setNotice("Crea tu primer servidor para empezar a chatear.");
    })();
    return () => { cancelled = true; };
  }, [session, supabase]);

  useEffect(() => {
    if (!session || !activeServer) { setChannels([]); setActiveChannel(""); return; }
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase.from("channels").select("*").eq("server_id", activeServer).order("created_at");
      if (cancelled) return;
      if (error) { setError(error.message); return; }
      const rows = (data || []) as Channel[];
      setChannels(rows);
      setActiveChannel(current => rows.some(c => c.id === current) ? current : (rows.find(c => c.type === "text")?.id || rows[0]?.id || ""));
    })();
    return () => { cancelled = true; };
  }, [session, activeServer, supabase]);

  useEffect(() => {
    if (!session || !activeChannel) { setMessages([]); return; }
    let cancelled = false;
    const load = async () => {
      const { data, error } = await supabase.from("messages")
        .select("id,channel_id,user_id,content,created_at,profiles(username,avatar_url)")
        .eq("channel_id", activeChannel).order("created_at", { ascending: true }).limit(100);
      if (cancelled) return;
      if (error) { setError(error.message); return; }
      setMessages((data || []) as unknown as ChatMessage[]);
    };
    load();
    const channel = supabase.channel(`messages:${activeChannel}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `channel_id=eq.${activeChannel}` }, async (payload) => {
        const row = payload.new as ChatMessage;
        const { data } = await supabase.from("profiles").select("username,avatar_url").eq("id", row.user_id).maybeSingle();
        setMessages(prev => prev.some(m => m.id === row.id) ? prev : [...prev, { ...row, profiles: data }]);
      }).subscribe();
    return () => { cancelled = true; supabase.removeChannel(channel); };
  }, [session, activeChannel, supabase]);

  const currentServer = servers.find(s => s.id === activeServer);
  const currentChannel = channels.find(c => c.id === activeChannel);
  const filteredMessages = useMemo(() => messages.filter(m => !search || m.content.toLowerCase().includes(search.toLowerCase())), [messages, search]);

  async function authenticate(e: React.FormEvent) {
    e.preventDefault(); setError(""); setNotice(""); setAuthBusy(true);
    try {
      if (authMode === "signup") {
        const { error } = await supabase.auth.signUp({ email, password, options: { data: { username: profileName.trim() || email.split("@")[0] } } });
        if (error) throw error;
        setNotice("Cuenta creada. Si la confirmación por correo está activada, revisa tu bandeja de entrada.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (e: any) { setError(e.message || "No se pudo iniciar sesión."); }
    finally { setAuthBusy(false); }
  }

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    const content = draft.trim();
    if (!content || !activeChannel || sending) return;
    setSending(true); setError("");
    const { error } = await supabase.from("messages").insert({ channel_id: activeChannel, user_id: session.user.id, content });
    if (error) setError(error.message); else setDraft("");
    setSending(false);
  }

  async function createServer(e: React.FormEvent) {
    e.preventDefault(); const name = modalName.trim(); if (!name) return;
    setError("");
    const { data, error } = await supabase.from("servers").insert({ name, owner_id: session.user.id }).select().single();
    if (error) { setError(error.message); return; }
    const { error: memberError } = await supabase.from("server_members").insert({ server_id: data.id, user_id: session.user.id, role: "owner" });
    if (memberError) { setError(memberError.message); return; }
    const { data: ch, error: chError } = await supabase.from("channels").insert([{ server_id: data.id, name: "general", type: "text" }, { server_id: data.id, name: "voz", type: "voice" }]).select();
    if (chError) { setError(chError.message); return; }
    setServers(prev => [...prev, data]); setActiveServer(data.id); setChannels(ch || []);
    setActiveChannel((ch || []).find((c: Channel) => c.type === "text")?.id || "");
    setModal(null); setModalName(""); setNotice(`Servidor "${name}" creado.`);
  }

  async function createChannel(e: React.FormEvent) {
    e.preventDefault(); const name = modalName.trim().toLowerCase().replace(/\s+/g, "-"); if (!name || !activeServer) return;
    const { data, error } = await supabase.from("channels").insert({ server_id: activeServer, name, type: "text" }).select().single();
    if (error) { setError(error.message); return; }
    setChannels(prev => [...prev, data]); setActiveChannel(data.id); setModal(null); setModalName("");
  }

  async function createInvite(e: React.FormEvent) {
    e.preventDefault(); if (!activeServer) return;
    const { data, error } = await supabase.from("invites").insert({ server_id: activeServer, created_by: session.user.id }).select("code").single();
    if (error) { setError(error.message); return; }
    const link = `${window.location.origin}/invite/${data.code}`;
    await navigator.clipboard.writeText(link);
    setNotice(`Enlace de invitación copiado: ${link}`); setModal(null);
  }

  async function joinServerByCode(e: React.FormEvent) {
    e.preventDefault(); const code = modalName.trim(); if (!code) return;
    const { data: invite, error } = await supabase.from("invites").select("server_id,expires_at,uses,max_uses").eq("code", code).maybeSingle();
    if (error || !invite) { setError("Invitación no válida."); return; }
    if ((invite.expires_at && new Date(invite.expires_at) < new Date()) || (invite.max_uses && invite.uses >= invite.max_uses)) { setError("Esta invitación ha caducado o alcanzó su límite."); return; }
    const { error: joinError } = await supabase.from("server_members").insert({ server_id: invite.server_id, user_id: session.user.id, role: "member" });
    if (joinError && !joinError.message.includes("duplicate")) { setError(joinError.message); return; }
    await supabase.from("invites").update({ uses: invite.uses + 1 }).eq("code", code);
    const { data: srv } = await supabase.from("servers").select("*").eq("id", invite.server_id).single();
    if (srv) { setServers(prev => prev.some(s => s.id === srv.id) ? prev : [...prev, srv]); setActiveServer(srv.id); }
    setModal(null); setModalName(""); setNotice("Te has unido al servidor.");
  }

  async function logout() { await supabase.auth.signOut(); setSession(null); }
  const initials = (profileName || session?.user?.email || "S").slice(0, 1).toUpperCase();

  if (loading) return <main className="loading-screen"><div className="brand-mark">S</div><p>Abriendo Snayder…</p></main>;

  if (!session) return <main className="auth-shell">
    <div className="auth-card">
      <div className="brand-mark">S</div><p className="eyebrow">TU GENTE. TUS COMUNIDADES.</p>
      <h1>{authMode === "login" ? "Qué bueno verte." : "Únete a Snayder."}</h1>
      <p className="muted">{authMode === "login" ? "Inicia sesión para volver a tus comunidades." : "Crea tu cuenta y empieza a conectar."}</p>
      <form onSubmit={authenticate} className="auth-form">
        {authMode === "signup" && <label>Nombre de usuario<input value={profileName} onChange={e => setProfileName(e.target.value)} minLength={2} maxLength={24} required placeholder="Tu nombre"/></label>}
        <label>Correo electrónico<input type="email" value={email} onChange={e => setEmail(e.target.value)} required placeholder="tu@correo.com" autoComplete="email"/></label>
        <label>Contraseña<input type="password" value={password} onChange={e => setPassword(e.target.value)} minLength={8} required placeholder="Mínimo 8 caracteres" autoComplete={authMode === "login" ? "current-password" : "new-password"}/></label>
        {error && <p className="error">{error}</p>}{notice && <p className="notice">{notice}</p>}
        <button className="primary wide" disabled={authBusy}>{authBusy ? "Un momento…" : authMode === "login" ? "Iniciar sesión" : "Crear cuenta"}</button>
      </form>
      <p className="switch-auth">{authMode === "login" ? "¿No tienes cuenta?" : "¿Ya tienes cuenta?"} <button onClick={() => {setAuthMode(authMode === "login" ? "signup" : "login");setError("");setNotice("");}}>{authMode === "login" ? "Regístrate" : "Inicia sesión"}</button></p>
      <p className="tiny muted">Al continuar aceptas las normas y la política de privacidad de Snayder.</p>
    </div>
  </main>;

  return <main className="app-shell">
    <aside className={`server-rail ${mobileSidebar ? "open" : ""}`}>
      <button className={`server-icon home-icon ${!activeServer ? "selected" : ""}`} title="Inicio">S</button>
      <div className="rail-divider"/>
      {servers.map((s, i) => <button key={s.id} title={s.name} onClick={() => {setActiveServer(s.id);setView("chat");setMobileSidebar(false)}} className={`server-icon ${s.id === activeServer ? "selected" : ""}`} style={{"--server-color":colors[i%colors.length]} as React.CSSProperties}>{s.name.slice(0,2).toUpperCase()}</button>)}
      <button className="server-icon add-server" title="Crear servidor" onClick={() => {setModal("server");setModalName("")}}><Plus/></button>
      <button className="server-icon add-server" title="Unirse a servidor" onClick={() => {setModal("invite");setModalName("")}}><UserPlus/></button>
    </aside>
    <aside className={`channel-sidebar ${mobileSidebar ? "open" : ""}`}>
      <div className="server-heading"><span>{currentServer?.name || "Tus comunidades"}</span><ChevronDown size={17}/></div>
      <button className={`nav-row ${view === "friends" ? "nav-active" : ""}`} onClick={() => {setView("friends");setMobileSidebar(false)}}><Users size={18}/> Amigos</button>
      <button className="nav-row" onClick={() => {setModal("invite");setModalName("")}}><Compass size={18}/> Unirse a comunidad</button>
      <div className="channel-heading"><span>CANALES DE TEXTO</span><button title="Crear canal" onClick={() => {setModal("channel");setModalName("")}}><Plus size={17}/></button></div>
      {channels.filter(c => c.type === "text").map(c => <button key={c.id} className={`channel-row ${activeChannel === c.id && view === "chat" ? "channel-active" : ""}`} onClick={() => {setActiveChannel(c.id);setView("chat");setMobileSidebar(false)}}><Hash size={17}/>{c.name}</button>)}
      <div className="channel-heading"><span>CANALES DE VOZ</span><Radio size={15}/></div>
      {channels.filter(c => c.type === "voice").map(c => <button key={c.id} className="channel-row" onClick={() => setNotice("Para voz en tiempo real hay que configurar un servicio WebRTC/LiveKit.")}><Headphones size={17}/>{c.name}</button>)}
      <div className="sidebar-bottom"><div className="online-dot"/><span>{profileName || session.user.email}</span><button title="Cerrar sesión" onClick={logout}><LogOut size={16}/></button></div>
    </aside>
    <section className="chat-panel">
      <header className="chat-header">
        <button className="mobile-menu" onClick={() => setMobileSidebar(!mobileSidebar)}><Menu/></button>
        {view === "chat" ? <><Hash size={20} className="muted-icon"/><strong>{currentChannel?.name || "Selecciona un canal"}</strong></> : <><Users size={20}/><strong>Amigos</strong></>}
        <div className="header-spacer"/>
        <div className="search-box"><Search size={16}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar mensajes"/></div>
        <button className="header-icon" title="Miembros" onClick={() => setShowMembers(!showMembers)}><Users size={19}/></button>
        <button className="header-icon" title="Notificaciones" onClick={() => setNotice("No tienes notificaciones nuevas.")}><Bell size={19}/></button>
      </header>
      {error && <div className="inline-alert error">{error}<button onClick={() => setError("")}><X size={14}/></button></div>}
      {notice && <div className="inline-alert">{notice}<button onClick={() => setNotice("")}><X size={14}/></button></div>}
      {view === "friends" ? <div className="empty-state"><div className="empty-icon"><Users/></div><h2>Tu comunidad empieza aquí</h2><p>Comparte un enlace de invitación para que tus amigos se unan a tu servidor.</p><button className="primary" onClick={() => setModal("invite")}>Invitar amigos</button></div> :
      !activeServer ? <div className="empty-state"><div className="empty-icon"><MessageCircle/></div><h2>Bienvenido a Snayder</h2><p>Crea tu primer servidor o únete a uno mediante invitación.</p><button className="primary" onClick={() => setModal("server")}>Crear mi servidor</button></div> :
      !activeChannel ? <div className="empty-state"><div className="empty-icon"><Hash/></div><h2>Empieza una conversación</h2><p>Crea un canal de texto para que tu comunidad pueda hablar.</p><button className="primary" onClick={() => setModal("channel")}>Crear canal</button></div> :
      <><div className="message-list" key={activeChannel}>
        <div className="channel-welcome"><div className="welcome-hash"><Hash size={28}/></div><h1>Bienvenido a #{currentChannel?.name}</h1><p>Este es el comienzo del canal. ¡Di hola!</p></div>
        {filteredMessages.map((m, i) => <article className="message" key={m.id}><div className="message-avatar" style={{background:colors[m.user_id.charCodeAt(0)%colors.length]}}>{(m.profiles?.username || "U").slice(0,1).toUpperCase()}</div><div className="message-body"><div className="message-meta"><strong>{m.profiles?.username || "Usuario"}</strong><time>{new Date(m.created_at).toLocaleString("es-ES",{day:"2-digit",month:"2-digit",hour:"2-digit",minute:"2-digit"})}</time></div><p>{m.content}</p></div></article>)}
      </div>
      <form className="composer" onSubmit={sendMessage}><button type="button" className="composer-add" title="Adjuntos" onClick={() => setNotice("Adjuntos: configura Supabase Storage para habilitarlos.")}><Plus size={21}/></button><input value={draft} onChange={e => setDraft(e.target.value)} placeholder={`Mensaje en #${currentChannel?.name}`} maxLength={4000} disabled={!activeChannel}/><button type="button" className="composer-tool" title="Emoji" onClick={() => setDraft(d => d + " 😀")}><Smile size={19}/></button><button className="send-button" disabled={!draft.trim() || sending} aria-label="Enviar mensaje"><Send size={18}/></button></form></>}
    </section>
    {showMembers && <aside className="members-panel"><h3>MIEMBROS</h3><p className="muted">Miembros del servidor</p><div className="member-entry"><div className="online-dot"/>{profileName || session.user.email}<span>tú</span></div><button className="secondary" onClick={() => setModal("invite")}>Invitar miembros</button></aside>}
    {modal && <div className="modal-backdrop" onMouseDown={e => {if(e.target === e.currentTarget)setModal(null)}}><form className="modal-card" onSubmit={modal === "server" ? createServer : modal === "channel" ? createChannel : modal === "invite" ? joinServerByCode : createInvite}>
      <button type="button" className="modal-close" onClick={() => setModal(null)}><X/></button>
      <div className="modal-symbol">{modal === "server" ? <ShieldCheck/> : modal === "channel" ? <Hash/> : <UserPlus/>}</div>
      <h2>{modal === "server" ? "Crea tu servidor" : modal === "channel" ? "Crear canal de texto" : "Únete a un servidor"}</h2>
      <p>{modal === "server" ? "Tu espacio para reunir a tu gente." : modal === "channel" ? "Dale un nombre fácil de reconocer." : "Pega el código de invitación que te han compartido."}</p>
      <label>{modal === "server" ? "Nombre del servidor" : modal === "channel" ? "Nombre del canal" : "Código de invitación"}
        <input value={modalName} onChange={e => setModalName(e.target.value)} required maxLength={60} placeholder={modal === "server" ? "Mi comunidad" : modal === "channel" ? "general" : "Código de invitación"}/>
      </label>
      <button className="primary wide" disabled={!modalName.trim()}>{modal === "server" ? "Crear servidor" : modal === "channel" ? "Crear canal" : "Unirme"}</button>
      <p className="tiny muted">Los datos se guardan en tu proyecto Supabase.</p>
    </form></div>}
  </main>;
}
